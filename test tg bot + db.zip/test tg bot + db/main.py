
import telebot
import sqlite3
API_TOKEN = '8328540055:AAGr0cvV6H7HvM32T4irVug6Z5Q6k4pBfIQ'

bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):

    db = sqlite3.connect('shop.db')
    c = db.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS products(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT,
              price INTEGER        
)""")

    db.commit()
    db.close()

    bot.reply_to(message, "Привет, это shop")

# /add apple 150 - новая строка в таблице product

@bot.message_handler(commands=['add'])
def post_product(message):
    product = message.text.split(maxsplit = 2)

    # print(product)

    db = sqlite3.connect('shop.db')
    c = db.cursor()

    c.execute("INSERT INTO products (name, price) VALUES (?, ?)", (product[1], int(product[2])))

    db.commit()
    db.close()
    bot.send_message(message.chat.id, "Товар добавлен" )

@bot.message_handler(commands=['view'])
def post_product(message):

    db = sqlite3.connect('shop.db')
    c = db.cursor()

    c.execute("SELECT * FROM products")
    products = c.fetchall()

    bot.send_message(message.chat.id, "Все товары:")

    for product in products:
        bot.send_message(message.chat.id, "id: " + str(product[0]) + "\nname: " + product[1] + "\nprice " + str(product[2]))

    db.close()

@bot.message_handler(func=lambda message: True)
def echo_message(message):
    bot.reply_to(message, message.text)


bot.infinity_polling()