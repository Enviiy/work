import telebot
from telebot import types
import crud.product as product_db
import crud.list as list_db

API_TOKEN = '8328540055:AAGr0cvV6H7HvM32T4irVug6Z5Q6k4pBfIQ'

bot = telebot.TeleBot(API_TOKEN)


@bot.message_handler(commands=['start'])
def send_welcome(message):
    # Регистрируем пользователя
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    
    product_db.init_tables()  # Создаем все таблицы
    product_db.register_user(user_id, username, first_name)  # Регистрируем пользователя
    
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    view_btn = types.KeyboardButton(text="/viewproducts")
    add_btn = types.KeyboardButton(text="/addproduct")
    upd_btn = types.KeyboardButton(text="/updateproduct")
    del_btn = types.KeyboardButton(text="/deleteproduct")
    newlist_btn = types.KeyboardButton(text="/newlist")
    viewlists_btn = types.KeyboardButton(text="/viewlists")
    additem_btn = types.KeyboardButton(text="/additem")
    showlist_btn = types.KeyboardButton(text="/showlist")
    kb.add(view_btn, add_btn, upd_btn, del_btn, newlist_btn, viewlists_btn, additem_btn, showlist_btn)
    
    bot.send_message(message.chat.id, 
                    f"Привет, {first_name}! Я бот для списка продуктов! \n\n"
                    "Пропиши /help - чтобы увидеть все мои команды!", 
                    reply_markup=kb)

@bot.message_handler(commands=['help'])
def send_help(message):
    bot.reply_to(message, "Список всех команд:"
        "\n\nПродукты" 
        "\n/addproduct - Добавить новый товар"
        "\n/viewproducts - Просмотр всех товаров"
        "\n/updateproduct - Изменить товар"
        "\n/deleteproduct - Удалить товар"
        
        "\n\nСписки покупок"
        "\n/newlist - Создать новый список"
        "\n/viewlists - Посмотреть все списки"
        "\n/additem - Добавить товар в список"
        "\n/showlist - Показать товары в списке"
        "\n/deleteitem - Удалить товар из списка"
        "\n/deletelist - Удалить список"
    )


# Добавление товара
@bot.message_handler(commands=['addproduct'])
def post_product(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите название товара.\n\nЕсли хотите отменить создание товара, введите \"Отмена.\"")
    bot.register_next_step_handler(message, create_product_name, user_id)

def create_product_name(message, user_id):
    if message.text != "Отмена.":
        name = message.text
        product = {}
        product['name'] = name
        bot.send_message(message.chat.id, "Введите цену товара.\n\nЕсли хотите отменить создание товара, введите \"Отмена.\"")
        bot.register_next_step_handler(message, create_product_price, user_id, product)
    else:
        bot.send_message(message.chat.id, "Отмена создания товара")

def create_product_price(message, user_id, product):
    if message.text != "Отмена.":
        price = message.text
        if price.isdigit():
            product['price'] = price
            product_db.create(user_id, product)
            bot.send_message(message.chat.id, "Товар добавлен")
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Цена должна состоять из цифр")
            bot.register_next_step_handler(message, create_product_price, user_id, product)
    else:
        bot.send_message(message.chat.id, "Отмена создания товара")

# Обновление товара
@bot.message_handler(commands=['updateproduct'])
def update_product(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите id товара, который хотите изменить.\n\nЕсли хотите отменить изменение товара, введите \"Отмена.\"")
    bot.register_next_step_handler(message, update_product_id, user_id)

def update_product_id(message, user_id):
    if message.text != "Отмена.":
        id = message.text
        if id.isdigit() and product_db.check_id(user_id, id):
            product = {}
            product['id'] = id
            bot.send_message(message.chat.id, "Введите то, что хотите поменять - Название или Цена.\n\nЕсли хотите отменить изменение товара, введите \"Отмена.\"")
            bot.register_next_step_handler(message, update_product_column, user_id, product)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите id товара ещё раз")
            bot.register_next_step_handler(message, update_product_id, user_id)
    else:
        bot.send_message(message.chat.id, "Отмена изменения товара")

def update_product_column(message, user_id, product):
    if message.text != "Отмена.":
        column = message.text
        if column in ['Название', 'Цена']:
            product['column'] = column
            bot.send_message(message.chat.id, "Введите то, на что хотите поменять.\n\nЕсли хотите отменить изменение товара, введите \"Отмена.\"")
            bot.register_next_step_handler(message, update_product_value, user_id, product)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите Название или Цена")
            bot.register_next_step_handler(message, update_product_column, user_id, product)
    else:
        bot.send_message(message.chat.id, "Отмена изменения товара")

def update_product_value(message, user_id, product):
    if message.text != "Отмена.":
        value = message.text
        if product['column'] == "Название":
            product['value'] = value
            product_db.update(user_id, product)
            bot.send_message(message.chat.id, "Товар обновлён")
        elif product['column'] == "Цена":
            if value.isdigit():
                product['value'] = value
                product_db.update(user_id, product)
                bot.send_message(message.chat.id, "Товар обновлён")
            else:
                bot.send_message(message.chat.id, "Неправильный ввод. Цена должна состоять из цифр")
                bot.register_next_step_handler(message, update_product_value, user_id, product)
    else:
        bot.send_message(message.chat.id, "Отмена изменения товара")

# Удаление товара
@bot.message_handler(commands=['deleteproduct'])
def delete_product(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите id товара, который хотите удалить.\n\nЕсли хотите отменить удаление товара, введите \"Отмена.\"")
    bot.register_next_step_handler(message, delete_product_id, user_id)

def delete_product_id(message, user_id):
    if message.text != "Отмена.":
        id = message.text
        if id.isdigit() and product_db.check_id(user_id, id):
            product = {}
            product['id'] = id
            bot.send_message(message.chat.id, "Вы уверены, что хотите удалить товар? Если да, то напишите \"Удалить.\"\n\nЕсли хотите отменить изменение товара, введите \"Отмена.\"")
            bot.register_next_step_handler(message, delete_product_check, user_id, product)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите id товара ещё раз")
            bot.register_next_step_handler(message, delete_product_id, user_id)
    else:
        bot.send_message(message.chat.id, "Отмена удаления товара")

def delete_product_check(message, user_id, product):
    if message.text != "Отмена.":
        if message.text == "Удалить.":
            product_db.delete(user_id, product)
            bot.send_message(message.chat.id, "Товар удалён")
    else:
        bot.send_message(message.chat.id, "Отмена удаления товара")

# Просмотр товара
@bot.message_handler(commands=['viewproduct'])
def view_product(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите id товара, который хотите посмотреть.\n\nЕсли хотите отменить просмотр товара, введите \"Отмена.\"")
    bot.register_next_step_handler(message, view_product_id, user_id)

def view_product_id(message, user_id):
    if message.text != "Отмена.":
        id = message.text
        if id.isdigit() and product_db.check_id(user_id, id):
            product = {}
            product['id'] = id
            one_product = product_db.read_one(user_id, product)
            bot.send_message(message.chat.id, f"id: {one_product['id']}\nНазвание: {one_product['name']}\nЦена: {one_product['price']}")
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите id товара ещё раз")
            bot.register_next_step_handler(message, view_product_id, user_id)
    else:
        bot.send_message(message.chat.id, "Отмена удаления товара")

# Просмотр всех товаров
@bot.message_handler(commands=['viewproducts'])
def view_products(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Все товары:")
    products = product_db.read(user_id)
    for product in products:
        kb = types.InlineKeyboardMarkup(row_width=1)
        view_btn = types.InlineKeyboardButton(text=f"Посмотреть", callback_data=f"/viewproduct {user_id} {product['id']}")
        update_btn = types.InlineKeyboardButton(text="\tИзменить\t", callback_data=f"/updateproduct {user_id} {product['id']}")
        delete_btn = types.InlineKeyboardButton(text="\tУдалить\t", callback_data=f"/deleteproduct {user_id} {product['id']}")
        kb.add(view_btn, update_btn, delete_btn)
        bot.send_message(message.chat.id, product['name'], reply_markup=kb)


# Создание нового списка
@bot.message_handler(commands=['newlist'])
def post_list(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите название списка.\n\nЕсли хотите отменить создание списка, введите \"Отмена.\"")
    bot.register_next_step_handler(message, create_list_name, user_id)

def create_list_name(message, user_id):
    if message.text != "Отмена.":
        name = message.text
        lst = {}
        lst['name'] = name
        list_db.create_list(user_id, lst)
        bot.send_message(message.chat.id, "Список создан")
    else:
        bot.send_message(message.chat.id, "Отмена создания списка")

# Просмотр всех списков
@bot.message_handler(commands=['viewlists'])
def view_lists(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Все списки:")
    lists = list_db.read_lists(user_id)
    for lst in lists:
        kb = types.InlineKeyboardMarkup(row_width=2)
        show_btn = types.InlineKeyboardButton(text=f"Показать", callback_data=f"/showlist {user_id} {lst['id']}")
        delete_btn = types.InlineKeyboardButton(text="\tУдалить\t", callback_data=f"/deletelist {user_id} {lst['id']}")
        kb.add(show_btn, delete_btn)
        bot.send_message(message.chat.id, f"{lst['name']} - {lst['total_price']} руб.", reply_markup=kb)

# Добавление товара в список
@bot.message_handler(commands=['additem'])
def add_item(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите id списка, в который хотите добавить товар.\n\nЕсли хотите отменить добавление, введите \"Отмена.\"")
    bot.register_next_step_handler(message, add_item_list_id, user_id)

def add_item_list_id(message, user_id):
    if message.text != "Отмена.":
        list_id = message.text
        if list_id.isdigit() and list_db.check_list_id(user_id, list_id):
            item = {}
            item['list_id'] = list_id
            bot.send_message(message.chat.id, "Введите название товара.\n\nЕсли хотите отменить добавление, введите \"Отмена.\"")
            bot.register_next_step_handler(message, add_item_name, user_id, item)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите id списка ещё раз")
            bot.register_next_step_handler(message, add_item_list_id, user_id)
    else:
        bot.send_message(message.chat.id, "Отмена добавления товара")

def add_item_name(message, user_id, item):
    if message.text != "Отмена.":
        product_name = message.text
        item['product_name'] = product_name
        bot.send_message(message.chat.id, "Введите количество товара.\n\nЕсли хотите отменить добавление, введите \"Отмена.\"")
        bot.register_next_step_handler(message, add_item_quantity, user_id, item)
    else:
        bot.send_message(message.chat.id, "Отмена добавления товара")

def add_item_quantity(message, user_id, item):
    if message.text != "Отмена.":
        quantity = message.text
        if quantity.isdigit():
            item['quantity'] = quantity
            bot.send_message(message.chat.id, "Введите цену товара.\n\nЕсли хотите отменить добавление, введите \"Отмена.\"")
            bot.register_next_step_handler(message, add_item_price, user_id, item)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Количество должно состоять из цифр")
            bot.register_next_step_handler(message, add_item_quantity, user_id, item)
    else:
        bot.send_message(message.chat.id, "Отмена добавления товара")

def add_item_price(message, user_id, item):
    if message.text != "Отмена.":
        price = message.text
        if price.isdigit():
            item['price'] = price
            if list_db.add_item(user_id, item):
                bot.send_message(message.chat.id, "Товар добавлен в список")
            else:
                bot.send_message(message.chat.id, "Ошибка: список не найден или нет доступа")
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Цена должна состоять из цифр")
            bot.register_next_step_handler(message, add_item_price, user_id, item)
    else:
        bot.send_message(message.chat.id, "Отмена добавления товара")

# Показать список
@bot.message_handler(commands=['showlist'])
def show_list(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите id списка, который хотите посмотреть.\n\nЕсли хотите отменить просмотр, введите \"Отмена.\"")
    bot.register_next_step_handler(message, show_list_id, user_id)

def show_list_id(message, user_id):
    if message.text != "Отмена.":
        list_id = message.text
        if list_id.isdigit() and list_db.check_list_id(user_id, list_id):
            lst = list_db.read_list(user_id, list_id)
            if lst:
                text = f"📋 Список: {lst['name']}\n"
                text += f"💰 Общая сумма: {lst['total_price']} руб.\n\n"
                
                if lst['items']:
                    for item in lst['items']:
                        status = "✅" if item['is_purchased'] else "⬜"
                        text += f"{status} {item['product_name']} - {item['quantity']} x {item['price']} руб. = {item['total']} руб.\n"
                else:
                    text += "Список пуст. Добавьте товары командой /additem"
                
                bot.send_message(message.chat.id, text)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите id списка ещё раз")
            bot.register_next_step_handler(message, show_list_id, user_id)
    else:
        bot.send_message(message.chat.id, "Отмена просмотра списка")

# Удаление товара из списка
@bot.message_handler(commands=['deleteitem'])
def delete_item_command(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите id товара, который хотите удалить из списка.\n\nЕсли хотите отменить удаление, введите \"Отмена.\"")
    bot.register_next_step_handler(message, delete_item_id, user_id)

def delete_item_id(message, user_id):
    if message.text != "Отмена.":
        item_id = message.text
        if item_id.isdigit() and list_db.check_item_id(user_id, item_id):
            bot.send_message(message.chat.id, "Вы уверены, что хотите удалить товар из списка? Если да, то напишите \"Удалить.\"\n\nЕсли хотите отменить удаление, введите \"Отмена.\"")
            bot.register_next_step_handler(message, delete_item_check, user_id, item_id)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите id товара ещё раз")
            bot.register_next_step_handler(message, delete_item_id, user_id)
    else:
        bot.send_message(message.chat.id, "Отмена удаления товара")

def delete_item_check(message, user_id, item_id):
    if message.text != "Отмена.":
        if message.text == "Удалить.":
            if list_db.delete_item(user_id, item_id):
                bot.send_message(message.chat.id, "Товар удалён из списка")
            else:
                bot.send_message(message.chat.id, "Ошибка: товар не найден или нет доступа")
    else:
        bot.send_message(message.chat.id, "Отмена удаления товара")

# Удаление списка
@bot.message_handler(commands=['deletelist'])
def delete_list_command(message):
    user_id = message.from_user.id
    bot.send_message(message.chat.id, "Введите id списка, который хотите удалить.\n\nЕсли хотите отменить удаление, введите \"Отмена.\"")
    bot.register_next_step_handler(message, delete_list_id, user_id)

def delete_list_id(message, user_id):
    if message.text != "Отмена.":
        list_id = message.text
        if list_id.isdigit() and list_db.check_list_id(user_id, list_id):
            bot.send_message(message.chat.id, "Вы уверены, что хотите удалить список? Если да, то напишите \"Удалить.\"\n\nЕсли хотите отменить удаление, введите \"Отмена.\"")
            bot.register_next_step_handler(message, delete_list_check, user_id, list_id)
        else:
            bot.send_message(message.chat.id, "Неправильный ввод. Введите id списка ещё раз")
            bot.register_next_step_handler(message, delete_list_id, user_id)
    else:
        bot.send_message(message.chat.id, "Отмена удаления списка")

def delete_list_check(message, user_id, list_id):
    if message.text != "Отмена.":
        if message.text == "Удалить.":
            list_db.delete_list(user_id, list_id)
            bot.send_message(message.chat.id, "Список удалён")
    else:
        bot.send_message(message.chat.id, "Отмена удаления списка")



@bot.message_handler(func=lambda message: True)
def echo_message(message):
    bot.reply_to(message, "Такой команды нет.")
 

bot.infinity_polling()