import sqlite3

def init_tables():
    """Инициализация всех таблиц"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    # Таблица пользователей
    c.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    
    # Таблица продуктов (с user_id)
    c.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            price INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
    )""")
    
    # Таблица списков (с user_id)
    c.execute("""CREATE TABLE IF NOT EXISTS lists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            total_price INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
    )""")
    
    # Таблица элементов списка
    c.execute("""CREATE TABLE IF NOT EXISTS list_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            list_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            quantity INTEGER DEFAULT 1,
            price INTEGER,
            is_purchased INTEGER DEFAULT 0,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (list_id) REFERENCES lists(id),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
    )""")
    
    db.commit()
    db.close()

def register_user(user_id, username, first_name):
    """Регистрация пользователя"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    # Проверяем, есть ли уже пользователь
    c.execute("SELECT COUNT(*) FROM users WHERE user_id = ?", (user_id,))
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (user_id, username, first_name) VALUES (?, ?, ?)",
                  (user_id, username, first_name))
    
    db.commit()
    db.close()

def check_id(user_id, product_id):
    """Проверка ID товара пользователя"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("SELECT EXISTS (SELECT 1 FROM products WHERE id = ? AND user_id = ?)", 
              (product_id, user_id))
    result = c.fetchall()[0][0]
    db.close()
    return result

def create(user_id, product):
    """Создание товара"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("INSERT INTO products (user_id, name, price) VALUES (?,?,?)", 
              (user_id, product['name'], product['price']))
    db.commit()
    db.close()

def update(user_id, product):
    """Обновление товара"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    if product['column'] == "Название":
        c.execute("UPDATE products SET name = ? WHERE id = ? AND user_id = ?", 
                  (product['value'], product['id'], user_id))
    if product['column'] == "Цена":
        c.execute("UPDATE products SET price = ? WHERE id = ? AND user_id = ?", 
                  (product['value'], product['id'], user_id))
    db.commit()
    db.close()

def delete(user_id, product):
    """Удаление товара"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("DELETE FROM products WHERE id = ? AND user_id = ?", 
              (product['id'], user_id))
    db.commit()
    db.close()

def read(user_id):
    """Чтение товаров пользователя"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("SELECT * FROM products WHERE user_id = ?", (user_id,))
    products_list = c.fetchall()
    products = []
    for product in products_list:
        one_product = {}
        one_product['id'] = product[0]
        one_product['user_id'] = product[1]
        one_product['name'] = product[2]
        one_product['price'] = product[3]
        products.append(one_product)
    db.close()
    return products

def read_one(user_id, product):
    """Чтение одного товара"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("SELECT * FROM products WHERE id = ? AND user_id = ?", 
              (product['id'], user_id))
    products_list = c.fetchall()
    one_product = {}
    for product in products_list:
        one_product['id'] = product[0]
        one_product['user_id'] = product[1]
        one_product['name'] = product[2]
        one_product['price'] = product[3]
    db.close()
    return one_product