import sqlite3

def check_list_id(user_id, list_id):
    """Проверка ID списка пользователя"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("SELECT EXISTS (SELECT 1 FROM lists WHERE id = ? AND user_id = ?)", 
              (list_id, user_id))
    result = c.fetchall()[0][0]
    db.close()
    return result

def check_item_id(user_id, item_id):
    """Проверка ID товара в списке пользователя"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("""SELECT EXISTS (
                    SELECT 1 FROM list_items li
                    JOIN lists l ON li.list_id = l.id
                    WHERE li.id = ? AND l.user_id = ?
                )""", (item_id, user_id))
    result = c.fetchall()[0][0]
    db.close()
    return result

def create_list(user_id, list_data):
    """Создание списка"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("INSERT INTO lists (user_id, name) VALUES (?,?)", 
              (user_id, list_data['name']))
    db.commit()
    db.close()

def add_item(user_id, item):
    """Добавление товара в список"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    # Проверяем, что список принадлежит пользователю
    c.execute("SELECT id FROM lists WHERE id = ? AND user_id = ?", 
              (item['list_id'], user_id))
    if not c.fetchone():
        db.close()
        return False
    
    c.execute("""INSERT INTO list_items (list_id, user_id, product_name, quantity, price) 
                 VALUES (?,?,?,?,?)""", 
              (item['list_id'], user_id, item['product_name'], item['quantity'], item['price']))
    
    # Обновляем сумму списка
    update_list_total(user_id, item['list_id'])
    
    db.commit()
    db.close()
    return True

def update_list_total(user_id, list_id):
    """Обновление общей суммы списка"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    c.execute("""SELECT SUM(quantity * price) 
                 FROM list_items 
                 WHERE list_id = ? AND user_id = ? AND is_purchased = 0""", 
              (list_id, user_id))
    
    total = c.fetchone()[0] or 0
    
    c.execute("UPDATE lists SET total_price = ? WHERE id = ? AND user_id = ?", 
              (total, list_id, user_id))
    
    db.commit()
    db.close()
    return total

def toggle_purchased(user_id, item_id):
    """Переключение статуса покупки"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    # Проверяем права доступа
    c.execute("""SELECT li.id, li.list_id, li.is_purchased 
                 FROM list_items li
                 JOIN lists l ON li.list_id = l.id
                 WHERE li.id = ? AND l.user_id = ?""", (item_id, user_id))
    
    result = c.fetchone()
    if not result:
        db.close()
        return False
    
    item_id, list_id, current = result
    new_status = 0 if current else 1
    
    c.execute("UPDATE list_items SET is_purchased = ? WHERE id = ?", (new_status, item_id))
    update_list_total(user_id, list_id)
    
    db.commit()
    db.close()
    return True

def delete_item(user_id, item_id):
    """Удаление товара из списка"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    # Получаем list_id перед удалением
    c.execute("""SELECT li.list_id 
                 FROM list_items li
                 JOIN lists l ON li.list_id = l.id
                 WHERE li.id = ? AND l.user_id = ?""", (item_id, user_id))
    
    result = c.fetchone()
    if not result:
        db.close()
        return False
    
    list_id = result[0]
    
    # Удаляем товар
    c.execute("DELETE FROM list_items WHERE id = ?", (item_id,))
    
    # Обновляем сумму списка
    update_list_total(user_id, list_id)
    
    db.commit()
    db.close()
    return True

def delete_list(user_id, list_id):
    """Удаление списка"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    # Удаляем сначала все товары из списка
    c.execute("""DELETE FROM list_items 
                 WHERE list_id IN (
                     SELECT id FROM lists WHERE id = ? AND user_id = ?
                 )""", (list_id, user_id))
    
    # Удаляем сам список
    c.execute("DELETE FROM lists WHERE id = ? AND user_id = ?", (list_id, user_id))
    
    db.commit()
    db.close()

def read_lists(user_id):
    """Чтение списков пользователя"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    c.execute("SELECT * FROM lists WHERE user_id = ?", (user_id,))
    lists_data = c.fetchall()
    lists = []
    for lst in lists_data:
        one_list = {}
        one_list['id'] = lst[0]
        one_list['user_id'] = lst[1]
        one_list['name'] = lst[2]
        one_list['total_price'] = lst[3]
        one_list['created_at'] = lst[4]
        lists.append(one_list)
    db.close()
    return lists

def read_list(user_id, list_id):
    """Чтение одного списка с товарами"""
    db = sqlite3.connect("shop.db")
    c = db.cursor()
    
    # Получаем информацию о списке
    c.execute("SELECT * FROM lists WHERE id = ? AND user_id = ?", (list_id, user_id))
    list_data = c.fetchone()
    
    if not list_data:
        db.close()
        return None
    
    one_list = {}
    one_list['id'] = list_data[0]
    one_list['user_id'] = list_data[1]
    one_list['name'] = list_data[2]
    one_list['total_price'] = list_data[3]
    one_list['created_at'] = list_data[4]
    
    # Получаем товары в этом списке
    c.execute("SELECT * FROM list_items WHERE list_id = ? AND user_id = ?", (list_id, user_id))
    items_data = c.fetchall()
    
    items = []
    for item in items_data:
        one_item = {}
        one_item['id'] = item[0]
        one_item['list_id'] = item[1]
        one_item['user_id'] = item[2]
        one_item['product_name'] = item[3]
        one_item['quantity'] = item[4]
        one_item['price'] = item[5]
        one_item['is_purchased'] = item[6]
        one_item['added_at'] = item[7]
        one_item['total'] = item[4] * item[5]
        items.append(one_item)
    
    one_list['items'] = items
    db.close()
    return one_list